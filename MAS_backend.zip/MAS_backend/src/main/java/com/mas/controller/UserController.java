package com.mas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.mas.model.User;
import com.mas.service.UserService;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @PostMapping
    public User addUser(@RequestBody User user) {
        return userService.addUser(user);
    }

    // API to update miles balance
    @PutMapping("/update-miles/{userId}")
    public User updateMilesBalance(@PathVariable Long userId, @RequestBody int miles) {
        return userService.updateMilesBalance(userId, miles);
    }
}
