// src/main/java/com/mas/controller/MilesRequestController.java
package com.mas.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mas.model.MilesRequest;
import com.mas.service.MilesRequestService;

@RestController
@RequestMapping("/api/miles")
@CrossOrigin(origins = "*")
public class MilesRequestController {

private final MilesRequestService service;

public MilesRequestController(MilesRequestService service) {
    this.service = service;
}

@GetMapping
public List<MilesRequest> getAll() {
    return service.getAll();
}

@PostMapping
public MilesRequest save(@RequestBody MilesRequest request) {
    return service.save(request);
}

@PutMapping("/{id}")
public MilesRequest updateStatus(@PathVariable Long id, @RequestParam String status) {
    return service.updateStatus(id, status);
}


}
