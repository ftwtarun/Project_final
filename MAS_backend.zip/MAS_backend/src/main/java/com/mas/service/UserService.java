package com.mas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mas.model.User;
import com.mas.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User addUser(User user) {
        if (user.getName() == null || user.getName().isBlank()) {
            throw new IllegalArgumentException("User name cannot be null or blank.");
        }

        if (user.getMiles() < 0) {
            throw new IllegalArgumentException("Miles must be a non-negative integer.");
        }

        return userRepository.save(user);
    }

    // Method to update miles balance
    public User updateMilesBalance(Long userId, int miles) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        user.setMiles(user.getMiles() + miles);  // Add the passed miles to the user's current balance
        return userRepository.save(user);
    }
}
