// src/main/java/com/mas/service/MilesRequestService.java
package com.mas.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mas.model.MilesRequest;
import com.mas.repository.MilesRequestRepository;

@Service
public class MilesRequestService {

    private final MilesRequestRepository repository;

    public MilesRequestService(MilesRequestRepository repository) {
        this.repository = repository;
    }

    public List<MilesRequest> getAll() {
        return repository.findAll();
    }

    public MilesRequest save(MilesRequest request) {
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email cannot be null or blank.");
        }
        if (request.getFlightNumber() == null || request.getFlightNumber().isBlank()) {
            throw new IllegalArgumentException("Flight number cannot be null or blank.");
        }
        if (request.getMiles() < 0) {
            throw new IllegalArgumentException("Miles must be a non-negative integer.");
        }
        if (request.getStatus() == null || request.getStatus().isBlank()) {
            throw new IllegalArgumentException("Status cannot be null or blank.");
        }

        return repository.save(request);
    }

    public MilesRequest updateStatus(Long id, String status) {
        if (status == null || status.isBlank()) {
            throw new IllegalArgumentException("Status cannot be null or blank.");
        }

        MilesRequest request = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Request with ID " + id + " not found."));

        request.setStatus(status);
        return repository.save(request);
    }
}
