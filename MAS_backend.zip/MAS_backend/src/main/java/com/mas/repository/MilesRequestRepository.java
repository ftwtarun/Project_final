// src/main/java/com/mas/repository/MilesRequestRepository.java
package com.mas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mas.model.MilesRequest;

public interface MilesRequestRepository extends JpaRepository<MilesRequest, Long> {
}
