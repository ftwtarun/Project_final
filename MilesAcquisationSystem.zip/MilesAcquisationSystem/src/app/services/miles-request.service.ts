import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface MilesRequest {
  email: string;
  flightNumber: string;
  miles: number;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class MilesRequestService {
  private apiUrl = 'http://localhost:8080/api/miles';

  constructor(private http: HttpClient) {}

  // Method to submit a new request (POST)
  submitRequest(request: MilesRequest): Observable<MilesRequest> {
    return this.http.post<MilesRequest>(this.apiUrl, request);
  }

  // Method to get all requests (GET)
  getAllRequests(): Observable<MilesRequest[]> {
    return this.http.get<MilesRequest[]>(this.apiUrl);
  }

  // Method to update the status of a request (PUT)
  updateStatus(id: number, status: string): Observable<MilesRequest> {
    // Update status by sending status directly
    return this.http.put<MilesRequest>(`${this.apiUrl}/${id}?status=${status}`, {});
  }
}
