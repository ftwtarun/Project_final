import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Reward, RedemptionRequest } from '../models/reward.model';

@Injectable({
  providedIn: 'root'
})
export class RewardService {
  private rewards: Reward[] = [
    {
      id: '1',
      name: 'Free Economy Flight',
      description: 'Redeem for a free economy class flight ticket',
      milesRequired: 25000,
      available: true
    },
    {
      id: '2',
      name: 'Business Class Upgrade',
      description: 'Upgrade your economy ticket to business class',
      milesRequired: 15000,
      available: true
    },
    {
      id: '3',
      name: 'Airport Lounge Access',
      description: 'One-time access to premium airport lounges',
      milesRequired: 5000,
      available: true
    }
  ];

  private redemptionRequests: RedemptionRequest[] = [];

  constructor() {}

  getRewards(): Observable<Reward[]> {
    return of(this.rewards);
  }

  getRewardById(rewardId: string): Reward | undefined {
    return this.rewards.find(r => r.id === rewardId);
  }

  redeemReward(userId: string, rewardId: string): Observable<RedemptionRequest> {
    const reward = this.rewards.find(r => r.id === rewardId);
    if (!reward) {
      throw new Error('Reward not found');
    }

    const request: RedemptionRequest = {
      id: Date.now().toString(),
      userId,
      rewardId,
      status: 'PENDING',
      requestDate: new Date().toISOString()
    };

    this.redemptionRequests.push(request);
    return of(request);
  }

  getUserRedemptions(userId: string): Observable<RedemptionRequest[]> {
    return of(this.redemptionRequests.filter(request => request.userId === userId));
  }

  // Admin methods
  getAllRedemptionRequests(): Observable<RedemptionRequest[]> {
    return of(this.redemptionRequests);
  }

  updateRedemptionStatus(requestId: string, status: 'APPROVED' | 'REJECTED'): Observable<RedemptionRequest> {
    const request = this.redemptionRequests.find(r => r.id === requestId);
    if (!request) {
      throw new Error('Redemption request not found');
    }

    request.status = status;
    return of(request);
  }
}