import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { User, AuthResponse } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  // Mock users data
  private users: User[] = [
    {
      id: '1',
      email: 'demo@example.com',
      firstName: 'Demo',
      lastName: 'User',
      role: 'FREQUENT_FLYER',
      milesBalance: 1000
    },
    {
      id: '2',
      email: 'admin@example.com',
      firstName: 'Admin',
      lastName: 'User',
      role: 'ADMIN',
      milesBalance: 0
    },
    {
      id: '3',
      email: 'staff@example.com',
      firstName: 'Staff',
      lastName: 'User',
      role: 'STAFF',
      milesBalance: 0
    }
  ];

  constructor() {
    // Check for stored user data on init
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }

  login(email: string, password: string): Observable<AuthResponse> {
    const user = this.users.find(u => u.email === email);
    
    if (user && password === 'password') {
      const response: AuthResponse = {
        user,
        token: 'dummy-jwt-token'
      };
      localStorage.setItem('currentUser', JSON.stringify(response.user));
      this.currentUserSubject.next(response.user);
      return of(response);
    }
    return throwError(() => new Error('Invalid credentials'));
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  isAuthenticated(): boolean {
    return !!this.currentUserSubject.value;
  }

  getAllUsers(): Observable<User[]> {
    return of(this.users);
  }
}