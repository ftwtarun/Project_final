import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Flight, MilesHistory } from '../models/flight.model';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  // Temporary storage until we connect to backend
  private flights: Flight[] = [];
  private milesHistory: MilesHistory[] = [];

  constructor() {}

  addFlight(flight: Omit<Flight, 'id' | 'milesEarned' | 'status'>): Observable<Flight> {
    const milesEarned = Math.floor(flight.distance * 0.1); // Basic miles calculation
    const newFlight: Flight = {
      ...flight,
      id: Date.now().toString(),
      milesEarned,
      status: 'PENDING'
    };
    this.flights.push(newFlight);
    
    const milesEntry: MilesHistory = {
      id: Date.now().toString(),
      userId: flight.userId,
      amount: milesEarned,
      type: 'EARNED',
      description: `Flight ${flight.flightNumber}`,
      date: new Date().toISOString()
    };
    this.milesHistory.push(milesEntry);

    return of(newFlight);
  }

  getUserFlights(userId: string): Observable<Flight[]> {
    return of(this.flights.filter(flight => flight.userId === userId));
  }

  getAllFlights(): Observable<Flight[]> {
    return of(this.flights);
  }

  updateFlightStatus(flightId: string, status: 'APPROVED' | 'REJECTED'): Observable<Flight> {
    const flight = this.flights.find(f => f.id === flightId);
    if (!flight) {
      throw new Error('Flight not found');
    }

    flight.status = status;
    return of(flight);
  }

  getMilesHistory(userId: string): Observable<MilesHistory[]> {
    return of(this.milesHistory.filter(history => history.userId === userId));
  }
}