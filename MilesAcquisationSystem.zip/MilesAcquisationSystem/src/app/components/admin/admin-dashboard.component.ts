import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FlightService } from '../../services/flight.service';
import { RewardService } from '../../services/reward.service';
import { Flight } from '../../models/flight.model';
import { User } from '../../models/user.model';
import { RedemptionRequest } from '../../models/reward.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="admin-container">
      <header class="admin-header">
        <h1>🛫 Airline Admin Dashboard</h1>
        <div class="user-info">
          <span>{{ user?.email }}</span>
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </header>

      <div class="admin-content">
        <section class="dashboard-section">
          <h2>🎁 Pending Reward Approvals</h2>
          <div class="card-grid">
            <div *ngFor="let request of redemptionRequests" class="card">
              <div class="card-body">
                <h3>Redemption Request</h3>
                <p><strong>User:</strong> {{ getUserEmail(request.userId) }}</p>
                <p><strong>Reward:</strong> {{ getRewardName(request.rewardId) }}</p>
                <p><strong>Date:</strong> {{ request.requestDate | date }}</p>
              </div>
              <div class="action-buttons">
                <button class="approve-btn" (click)="approveRequest(request.id!)">✅ Approve</button>
                <button class="reject-btn" (click)="rejectRequest(request.id!)">❌ Reject</button>
              </div>
            </div>
          </div>
        </section>

        <section class="dashboard-section">
          <h2>👤 User Management</h2>
          <div class="card-grid">
            <div *ngFor="let user of users" class="card">
              <div class="card-body">
                <h3>{{ user.firstName }} {{ user.lastName }}</h3>
                <p><strong>Email:</strong> {{ user.email }}</p>
                <p><strong>Role:</strong> {{ user.role }}</p>
                <p><strong>Miles Balance:</strong> {{ user.milesBalance }}</p>
              </div>
            </div>
          </div>
        </section>

        <section class="dashboard-section">
          <h2>✈️ Flight Management</h2>
          <div class="card-grid">
            <div *ngFor="let flight of flights" class="card">
              <div class="card-body">
                <h3>Flight {{ flight.flightNumber }}</h3>
                <p><strong>Date:</strong> {{ flight.departureDate | date }}</p>
                <p><strong>Distance:</strong> {{ flight.distance }} miles</p>
                <p><strong>Miles Earned:</strong> {{ flight.milesEarned }}</p>
                <p><strong>Status:</strong> {{ flight.status }}</p>
              </div>
              <div *ngIf="flight.status === 'PENDING'" class="action-buttons">
                <button class="approve-btn" (click)="approveFlight(flight.id!)">✅ Approve</button>
                <button class="reject-btn" (click)="rejectFlight(flight.id!)">❌ Reject</button>
              </div>
            </div>
          </div>
        </section>
      </div>

      <!-- Footer Section -->
      <footer class="footer">
        <button class="footer-toggle" (click)="toggleFooter()">👥 Meet Our Team</button>
        <div *ngIf="showFooter" class="footer-content">
          <h3>Team Breeze</h3>
          <ul>
            <li>Tarun Kumar (21ESKIT109)</li>
            <li>Verma Devashish (21ESKIT114)</li>
            <li>Nighat Shakoor (21ESKIT310)</li>
          </ul>
        </div>
      </footer>
    </div>
  `,
  styles: [`
    .admin-container {
      max-width: 1300px;
      margin: 0 auto;
      padding: 2rem;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to bottom right, #e0f7fa, #00796b);
    }

    .admin-header {
      position: sticky;
      top: 0;
      z-index: 10;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #005f5f; /* Darker shade of teal */
      color: white;
      padding: 1rem 2rem;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .logout-btn {
      padding: 0.5rem 1rem;
      background-color: #e63946;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .logout-btn:hover {
      background-color: #c82333;
    }

    .admin-content {
      margin-top: 2rem;
      display: flex;
      flex-direction: column;
      gap: 2.5rem;
    }

    .dashboard-section {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.08);
    }

    h2 {
      margin-bottom: 1.5rem;
      color: #005f5f;
      font-size: 1.6rem;
      border-bottom: 2px solid #ccc;
      padding-bottom: 0.5rem;
    }

    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.5rem;
    }

    .card {
      background: #ffffff;
      border-left: 5px solid #00796b;
      padding: 1.25rem;
      border-radius: 8px;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .card:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    }

    .card-body h3 {
      margin-bottom: 0.5rem;
      color: #00796b;
    }

    .card-body p {
      margin: 0.25rem 0;
      color: #444;
    }

    .action-buttons {
      margin-top: 1rem;
      display: flex;
      gap: 0.75rem;
    }

    .approve-btn, .reject-btn {
      flex: 1;
      padding: 0.5rem;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .approve-btn {
      background-color: #28a745;
      color: white;
    }

    .approve-btn:hover {
      background-color: #218838;
    }

    .reject-btn {
      background-color: #dc3545;
      color: white;
    }

    .reject-btn:hover {
      background-color: #c82333;
    }

    /* Footer Styles */
    .footer {
      margin-top: 3rem;
      text-align: center;
      padding: 1rem;
      background-color: #004d40; /* Darker shade of teal */
      color: white;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .footer-toggle {
      background-color: #00796b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 0.75rem 1.5rem;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .footer-toggle:hover {
      background-color: #004d40;
    }

    .footer-content {
      margin-top: 1rem;
      font-size: 1.2rem;
      list-style-type: none;
    }

    .footer-content h3 {
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }

    .footer-content ul {
      list-style-type: none;
      padding-left: 0;
    }

    .footer-content li {
      margin: 0.25rem 0;
    }

    @media (max-width: 768px) {
      .admin-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
      }
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  user: User | null = null;
  users: User[] = [];
  flights: Flight[] = [];
  redemptionRequests: RedemptionRequest[] = [];
  showFooter: boolean = false;

  constructor(
    private authService: AuthService,
    private flightService: FlightService,
    private rewardService: RewardService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.user = user;
      if (user?.role !== 'ADMIN') {
        this.router.navigate(['/login']);
      } else {
        this.loadAdminData();
      }
    });
  }

  loadAdminData() {
    this.authService.getAllUsers().subscribe(users => {
      this.users = users;
    });

    this.flightService.getAllFlights().subscribe(flights => {
      this.flights = flights;
    });

    this.rewardService.getAllRedemptionRequests().subscribe(requests => {
      this.redemptionRequests = requests;
    });
  }

  getUserEmail(userId: string): string {
    return this.users.find(u => u.id === userId)?.email || 'Unknown User';
  }

  getRewardName(rewardId: string): string {
    const reward = this.rewardService.getRewardById(rewardId);
    return reward?.name || 'Unknown Reward';
  }

  approveRequest(requestId: string) {
    this.rewardService.updateRedemptionStatus(requestId, 'APPROVED').subscribe(() => {
      this.loadAdminData();
    });
  }

  rejectRequest(requestId: string) {
    this.rewardService.updateRedemptionStatus(requestId, 'REJECTED').subscribe(() => {
      this.loadAdminData();
    });
  }

  approveFlight(flightId: string) {
    this.flightService.updateFlightStatus(flightId, 'APPROVED').subscribe(() => {
      this.loadAdminData();
    });
  }

  rejectFlight(flightId: string) {
    this.flightService.updateFlightStatus(flightId, 'REJECTED').subscribe(() => {
      this.loadAdminData();
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  toggleFooter() {
    this.showFooter = !this.showFooter;
  }
}
