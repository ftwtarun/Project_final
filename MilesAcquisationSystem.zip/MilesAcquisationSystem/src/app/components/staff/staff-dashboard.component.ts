import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FlightService } from '../../services/flight.service';
import { MilesRequestService, MilesRequest } from '../../services/miles-request.service';
import { Flight } from '../../models/flight.model';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-staff-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="staff-container">
      <header class="staff-header">
        <h1>Staff Dashboard</h1>
        <div class="user-info">
          <span>{{ user?.email }}</span>
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </header>

      <div class="staff-content">
        <section class="flight-verification">
          <h2>Flight Verifications</h2>
          <div class="flight-list">
            <div *ngFor="let flight of pendingFlights" class="flight-card">
              <div class="flight-info">
                <h3>Flight {{ flight.flightNumber }}</h3>
                <p>Date: {{ flight.departureDate | date }}</p>
                <p>Distance: {{ flight.distance }} miles</p>
                <p>User: {{ getUserEmail(flight.userId) }}</p>
              </div>
              <div class="action-buttons">
                <button class="approve-btn" (click)="approveFlight(flight.id!)">Verify</button>
                <button class="reject-btn" (click)="rejectFlight(flight.id!)">Reject</button>
              </div>
            </div>
          </div>
        </section>

        <section class="flight-history">
          <h2>Verified Flights</h2>
          <div class="flight-list">
            <div *ngFor="let flight of verifiedFlights" class="flight-card verified">
              <div class="flight-info">
                <h3>Flight {{ flight.flightNumber }}</h3>
                <p>Date: {{ flight.departureDate | date }}</p>
                <p>Distance: {{ flight.distance }} miles</p>
                <p>Status: {{ flight.status }}</p>
                <p>User: {{ getUserEmail(flight.userId) }}</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  `,
  styles: [`
    /* Main container styles */
    .staff-container {
      font-family: 'Roboto', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      background: #f9fafb;
      padding: 20px;
    }

    /* Header styling */
    .staff-header {
      width: 100%;
      background-color: #0072ff;
      color: white;
      padding: 1.5rem;
      text-align: center;
      font-size: 1.6rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .user-info {
      display: flex;
      align-items: center;
      font-size: 1rem;
    }

    .user-info span {
      margin-right: 1rem;
    }

    .logout-btn {
      background-color: #ff4d4d;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      cursor: pointer;
      border-radius: 4px;
      transition: background-color 0.3s;
    }

    .logout-btn:hover {
      background-color: #ff1a1a;
    }

    /* Content Section Styling */
    .staff-content {
      width: 100%;
      margin-top: 2rem;
    }

    h2 {
      color: #333;
      margin-bottom: 1rem;
      font-size: 1.4rem;
      font-weight: 600;
    }

    .flight-list {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      justify-content: flex-start;
    }

    /* Flight Card Styling */
    .flight-card {
      background-color: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 280px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .flight-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }

    .flight-card h3 {
      font-size: 1.3rem;
      color: #333;
      margin-bottom: 1rem;
    }

    .flight-info p {
      font-size: 1rem;
      color: #555;
    }

    /* Action Buttons Styling */
    .action-buttons {
      margin-top: 1rem;
      display: flex;
      gap: 0.5rem;
    }

    .approve-btn, .reject-btn {
      padding: 0.5rem 1rem;
      border-radius: 4px;
      cursor: pointer;
      font-size: 1rem;
      color: white;
      transition: background-color 0.3s ease;
    }

    .approve-btn {
      background-color: #28a745;
    }

    .approve-btn:hover {
      background-color: #218838;
    }

    .reject-btn {
      background-color: #dc3545;
    }

    .reject-btn:hover {
      background-color: #c82333;
    }

    /* Verified Flight Card Styling */
    .verified {
      background-color: #d4edda;
    }

    .verified .approve-btn,
    .verified .reject-btn {
      cursor: not-allowed;
      background-color: #6c757d;
    }

    .verified .approve-btn:hover,
    .verified .reject-btn:hover {
      background-color: #6c757d;
    }
  `]
})
export class StaffDashboardComponent implements OnInit {
  user: User | null = null;
  pendingFlights: Flight[] = [];
  verifiedFlights: Flight[] = [];
  users: User[] = [];

  constructor(
    private authService: AuthService,
    private flightService: FlightService,
    private milesRequestService: MilesRequestService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.user = user;
      if (user?.role !== 'STAFF') {
        this.router.navigate(['/login']);
      } else {
        this.loadStaffData();
      }
    });
  }

  loadStaffData() {
    this.authService.getAllUsers().subscribe(users => {
      this.users = users;
    });

    this.flightService.getAllFlights().subscribe(flights => {
      this.pendingFlights = flights.filter(f => f.status === 'PENDING');
      this.verifiedFlights = flights.filter(f => f.status !== 'PENDING');
    });
  }

  getUserEmail(userId: string): string {
    return this.users.find(u => u.id === userId)?.email || 'Unknown User';
  }

  approveFlight(flightId: string) {
    this.flightService.updateFlightStatus(flightId, 'APPROVED').subscribe(() => {
      const flight = this.pendingFlights.find(f => f.id === flightId);
      const passengerEmail = flight ? this.getUserEmail(flight.userId) : '';

      if (flight && passengerEmail) {
        const request: MilesRequest = {
          email: passengerEmail,
          flightNumber: flight.flightNumber,
          miles: flight.distance,
          status: 'APPROVED'
        };

        this.milesRequestService.submitRequest(request).subscribe({
          next: () => console.log('Miles request submitted successfully'),
          error: err => console.error('Error submitting miles request:', err)
        });
      }

      this.loadStaffData();
    });
  }

  rejectFlight(flightId: string) {
    this.flightService.updateFlightStatus(flightId, 'REJECTED').subscribe(() => {
      this.loadStaffData();
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
