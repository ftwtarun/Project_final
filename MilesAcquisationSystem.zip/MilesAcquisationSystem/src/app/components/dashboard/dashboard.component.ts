import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FlightService } from '../../services/flight.service';
import { RewardService } from '../../services/reward.service';
import { Flight, MilesHistory } from '../../models/flight.model';
import { User } from '../../models/user.model';
import { Reward } from '../../models/reward.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="dashboard-container">
      <header class="dashboard-header">
        <h1>Welcome, {{ user?.firstName }}!</h1>
        <div class="miles-balance">
          <span>Miles Balance:</span>
          <strong>{{ user?.milesBalance }}</strong>
        </div>
        <button class="logout-btn" (click)="logout()">Logout</button>
      </header>

      <div class="dashboard-content">
        <section class="add-flight-section">
          <h2>Log a New Flight</h2>
          <form [formGroup]="flightForm" (ngSubmit)="onSubmitFlight()">
            <div class="form-group">
              <label for="flightNumber">Flight Number</label>
              <input
                type="text"
                id="flightNumber"
                formControlName="flightNumber"
                class="form-control"
                placeholder="e.g., AA123"
              />
            </div>
            <div class="form-group">
              <label for="departureDate">Departure Date</label>
              <input
                type="date"
                id="departureDate"
                formControlName="departureDate"
                class="form-control"
              />
            </div>
            <div class="form-group">
              <label for="distance">Distance (miles)</label>
              <input
                type="number"
                id="distance"
                formControlName="distance"
                class="form-control"
                placeholder="Enter flight distance"
              />
            </div>
            <button type="submit" [disabled]="!flightForm.valid">Log Flight</button>
          </form>
        </section>

        <section class="rewards-section">
          <h2>Available Rewards</h2>
          <div class="rewards-list">
            <div *ngFor="let reward of rewards" class="reward-card">
              <div class="reward-info">
                <h3>{{ reward.name }}</h3>
                <p>{{ reward.description }}</p>
                <strong>{{ reward.milesRequired }} miles</strong>
              </div>
              <button
                [disabled]="user?.milesBalance! < reward.milesRequired"
                (click)="redeemReward(reward)"
                class="redeem-btn"
              >
                Redeem
              </button>
            </div>
          </div>
        </section>

        <section class="flight-history-section">
          <h2>Flight History</h2>
          <div class="flight-list">
            <div *ngFor="let flight of flights" class="flight-card">
              <div class="flight-info">
                <strong>{{ flight.flightNumber }}</strong>
                <span>{{ flight.departureDate | date }}</span>
              </div>
              <div class="flight-miles">
                <span>Distance: {{ flight.distance }} miles</span>
                <span>Miles Earned: {{ flight.milesEarned }}</span>
                <span class="status" [class]="flight.status.toLowerCase()">
                  {{ flight.status }}
                </span>
              </div>
            </div>
          </div>
        </section>

        <section class="miles-history-section">
          <h2>Miles History</h2>
          <div class="miles-list">
            <div *ngFor="let history of milesHistory" class="miles-card">
              <div class="miles-info">
                <span>{{ history.date | date }}</span>
                <strong [class]="history.type.toLowerCase()">
                  {{ history.type === 'EARNED' ? '+' : '-' }}{{ history.amount }}
                </strong>
              </div>
              <p>{{ history.description }}</p>
            </div>
          </div>
        </section>
      </div>

      <footer class="footer">
        <p>&copy; 2025 Miles Acquisition System | All rights reserved.</p>
      </footer>
    </div>
  `,
  styles: [`
    .dashboard-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
    }

    .dashboard-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #007bff;
      color: #f0f8ff; /* Lighter color for text */
      padding: 1.5rem;
      border-radius: 6px;
      margin-bottom: 2rem;
    }

    .dashboard-header h1 {
      margin: 0;
    }

    .miles-balance {
      font-size: 1.2rem;
    }

    .miles-balance strong {
      margin-left: 0.5rem;
      color: #f8f9fa;
    }

    .logout-btn {
      padding: 0.5rem 1rem;
      background-color: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .dashboard-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-bottom: 3rem;
    }

    .add-flight-section, .rewards-section {
      grid-column: 1 / -1;
    }

    .flight-card, .miles-card, .reward-card {
      background: white;
      padding: 1rem;
      border-radius: 4px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      margin-bottom: 1rem;
    }

    .reward-card {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .reward-info {
      flex: 1;
    }

    .redeem-btn {
      padding: 0.5rem 1rem;
      background-color: #28a745;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .redeem-btn:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }

    .flight-info, .miles-info {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
    }

    .flight-miles {
      display: flex;
      flex-direction: column;
      font-size: 0.9rem;
      color: #666;
    }

    .status {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      font-size: 0.8rem;
      font-weight: bold;
    }

    .pending {
      background-color: #ffd700;
      color: #000;
    }

    .approved {
      background-color: #28a745;
      color: white;
    }

    .rejected {
      background-color: #dc3545;
      color: white;
    }

    .earned {
      color: #28a745;
    }

    .redeemed {
      color: #dc3545;
    }

    .footer {
      text-align: center;
      padding: 1rem;
      background-color: #343a40;
      color: #f0f8ff; /* Lighter color for text */
      margin-top: 2rem;
      border-radius: 6px;
    }
  `]
})
export class DashboardComponent implements OnInit {
  user: User | null = null;
  flights: Flight[] = [];
  milesHistory: MilesHistory[] = [];
  rewards: Reward[] = [];

  flightForm = new FormGroup({
    flightNumber: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9]{2,6}$/)]),
    departureDate: new FormControl('', [Validators.required]),
    distance: new FormControl<number>(0, [Validators.required, Validators.min(1)]),
  });

  constructor(
    private authService: AuthService,
    private flightService: FlightService,
    private rewardService: RewardService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.user = user;
      if (user) {
        this.loadUserData(user.id!);
      } else {
        this.router.navigate(['/login']);
      }
    });

    this.rewardService.getRewards().subscribe((rewards: Reward[]) => {
      this.rewards = rewards;
    });
  }

  loadUserData(userId: string) {
    this.flightService.getUserFlights(userId).subscribe(flights => {
      this.flights = flights;
    });

    this.flightService.getMilesHistory(userId).subscribe(history => {
      this.milesHistory = history;
    });
  }

  onSubmitFlight() {
    if (this.flightForm.valid && this.user) {
      const flight = {
        ...this.flightForm.value,
        userId: this.user.id!
      } as Omit<Flight, 'id' | 'milesEarned' | 'status'>;

      this.flightService.addFlight(flight).subscribe(newFlight => {
        this.flights = [...this.flights, newFlight];
        this.flightForm.reset();
      });
    }
  }

  redeemReward(reward: Reward) {
    if (this.user && this.user.milesBalance! >= reward.milesRequired) {
      this.rewardService.redeemReward(this.user.id!, reward.id!).subscribe(() => {
        this.loadUserData(this.user!.id!);
      });
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
