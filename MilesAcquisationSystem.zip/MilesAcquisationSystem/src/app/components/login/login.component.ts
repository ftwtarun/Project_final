import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page-wrapper">
      <div class="clouds"></div>
      <div class="aviation-bg">
        ✈️
      </div>
      <div class="team-banner">
        <h1>Team Breeze</h1>
        <p>Your Gateway to Sky-high Rewards</p>
      </div>
      <div class="login-container">
        <div class="login-box">
          <h2 class="title">MAS Login</h2>
          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
            <div class="form-group">
              <label for="email">Email</label>
              <input
                type="email"
                id="email"
                formControlName="email"
                class="form-control"
                placeholder="Email Address"
              />
              <div *ngIf="loginForm.controls['email'].invalid && loginForm.controls['email'].touched" class="error-message">
                <div *ngIf="loginForm.controls['email'].errors?.['required']">Email is required.</div>
                <div *ngIf="loginForm.controls['email'].errors?.['email']">Please enter a valid email address.</div>
              </div>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input
                type="password"
                id="password"
                formControlName="password"
                class="form-control"
                placeholder="Password"
              />
              <div *ngIf="loginForm.controls['password'].invalid && loginForm.controls['password'].touched" class="error-message">
                Password is required.
              </div>
            </div>
            <button type="submit" [disabled]="!loginForm.valid || isLoading" class="login-btn">
              <span *ngIf="isLoading">Logging in...</span>
              <span *ngIf="!isLoading">Login</span>
            </button>
            <p *ngIf="error" class="error-message">{{ error }}</p>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100vh;
      font-family: 'Segoe UI', sans-serif;
    }

    .page-wrapper {
      position: relative;
      height: 100vh;
      background: linear-gradient(to bottom, #d0e9ff, #f0f9ff);
      overflow: hidden;
    }

    .clouds {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 200%;
      background-image: url('data:image/svg+xml;utf8,<svg width="300" height="100" xmlns="http://www.w3.org/2000/svg"><g fill="white" opacity="0.35"><ellipse cx="50" cy="50" rx="40" ry="25"/><ellipse cx="90" cy="45" rx="35" ry="20"/><ellipse cx="70" cy="60" rx="45" ry="25"/></g></svg>');
      background-repeat: repeat-x;
      background-size: contain;
      animation: moveClouds 80s linear infinite;
      z-index: 0;
    }

    @keyframes moveClouds {
      from { transform: translateX(0); }
      to { transform: translateX(-50%); }
    }

    .aviation-bg {
      position: absolute;
      top: 20%;
      left: 5%;
      pointer-events: none;
      z-index: 1;
    }

    .aviation-bg::after {
      content: '✈️';
      font-size: 3rem;
      display: inline-block;
      animation: floatPlane 6s ease-in-out infinite;
      opacity: 0.4;
    }

    @keyframes floatPlane {
      0%, 100% {
        transform: translateY(0) translateX(0) rotate(-10deg);
      }
      50% {
        transform: translateY(-15px) translateX(15px) rotate(5deg);
      }
    }

    .team-banner {
      background: rgba(255, 255, 255, 0.3);
      padding: 1rem 2rem;
      text-align: center;
      color: #004e8a;
      font-weight: 600;
      font-size: 1.2rem;
      backdrop-filter: blur(6px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.3);
      z-index: 2;
      position: relative;
    }

    .team-banner h1 {
      margin: 0;
      font-size: 2rem;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .team-banner p {
      margin: 0;
      font-size: 0.95rem;
      opacity: 0.85;
    }

    .login-container {
      height: calc(100vh - 80px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      position: relative;
      z-index: 2;
    }

    .login-box {
      background: #ffffff;
      border-radius: 1rem;
      padding: 2.5rem 2rem;
      max-width: 400px;
      width: 100%;
      box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
      animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(15px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .title {
      font-size: 1.8rem;
      font-weight: 700;
      text-align: center;
      margin-bottom: 1.8rem;
      color: #004e8a;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 600;
      color: #333;
    }

    .form-control {
      width: 100%;
      padding: 0.75rem 1rem;
      border-radius: 0.5rem;
      border: 1px solid #ccc;
      font-size: 1rem;
      transition: border 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
      outline: none;
      border-color: #0072ff;
      box-shadow: 0 0 0 4px rgba(0, 114, 255, 0.1);
    }

    .login-btn {
      width: 100%;
      padding: 0.9rem;
      background-color: #0072ff;
      color: white;
      border: none;
      border-radius: 0.5rem;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .login-btn:hover {
      background-color: #005bb5;
    }

    .login-btn:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }

    .error-message {
      color: #e53935;
      font-size: 0.875rem;
      margin-top: 0.5rem;
    }
  `]
})
export class LoginComponent {
  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required])
  });

  error: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    if (this.loginForm.valid) {
      this.isLoading = true;
      const { email, password } = this.loginForm.value;
      this.authService.login(email!, password!)
        .subscribe({
          next: (response) => {
            this.isLoading = false;
            switch (response.user.role) {
              case 'ADMIN':
                this.router.navigate(['/admin']);
                break;
              case 'STAFF':
                this.router.navigate(['/staff']);
                break;
              case 'FREQUENT_FLYER':
                this.router.navigate(['/dashboard']);
                break;
              default:
                this.router.navigate(['/dashboard']);
            }
          },
          error: (err) => {
            this.isLoading = false;
            this.error = err?.message || 'An error occurred. Please try again later.';
          }
        });
    }
  }
}
