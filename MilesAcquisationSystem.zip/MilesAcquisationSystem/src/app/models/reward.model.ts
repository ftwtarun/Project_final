export interface Reward {
  id?: string;
  name: string;
  description: string;
  milesRequired: number;
  available: boolean;
}

export interface RedemptionRequest {
  id?: string;
  userId: string;
  rewardId: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestDate: string;
}