export interface Flight {
  id?: string;
  flightNumber: string;
  departureDate: string;
  distance: number;
  milesEarned: number;
  userId: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

export interface MilesHistory {
  id?: string;
  userId: string;
  amount: number;
  type: 'EARNED' | 'REDEEMED';
  description: string;
  date: string;
}